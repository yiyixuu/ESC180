def not_string(str):
    return str if str[:3] == 'not' else "not " + str