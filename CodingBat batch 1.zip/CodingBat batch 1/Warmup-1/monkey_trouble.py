def monkey_trouble(a_smile, b_smile):
    return a_smile == b_smile