def sleep_in(weekday, vacation):
    return not weekday or vacation