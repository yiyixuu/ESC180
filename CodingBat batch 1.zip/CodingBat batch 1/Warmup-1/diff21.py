def diff21(n):
    return abs(n - 21) if n <= 21 else 2 * abs(n - 21)