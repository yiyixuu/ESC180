def front3(str):
    return str[:3] * 3