def missing_char(str, n):
    return str.replace(str[n], '')