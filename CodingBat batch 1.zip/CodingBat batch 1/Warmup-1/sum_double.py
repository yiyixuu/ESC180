def sum_double(a, b):
    return 2 * (a + b) if a == b else a + b