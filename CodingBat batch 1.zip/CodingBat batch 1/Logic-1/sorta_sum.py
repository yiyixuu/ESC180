def sorta_sum(a, b):
    return 20 if 10 <= a + b <= 19 else a+b