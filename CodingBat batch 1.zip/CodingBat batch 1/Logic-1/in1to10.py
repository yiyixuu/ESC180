def in1to10(n, outside_mode):
    return (n <= 1 or n >= 10) if outside_mode else (n >= 1 and n <= 10)