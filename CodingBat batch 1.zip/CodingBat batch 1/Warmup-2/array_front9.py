def array_front9(nums):
    return 9 in nums[:4]