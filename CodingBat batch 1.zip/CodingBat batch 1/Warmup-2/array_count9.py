def array_count9(nums):
    return sum([1 for i in nums if i == 9])