def array123(nums):
    return 1 and 2 and 3 in nums