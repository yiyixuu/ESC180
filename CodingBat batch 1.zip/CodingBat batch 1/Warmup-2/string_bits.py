def string_bits(str):
    return str[::2]