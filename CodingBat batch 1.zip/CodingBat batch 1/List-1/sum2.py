def sum2(nums):
    return sum(nums[:2])