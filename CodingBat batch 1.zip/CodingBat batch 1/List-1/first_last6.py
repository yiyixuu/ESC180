def first_last6(nums):
    return 6 == nums[0] or 6 == nums[-1]